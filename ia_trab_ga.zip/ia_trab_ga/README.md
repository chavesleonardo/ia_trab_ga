# ia_trab_ga
Trabalho do Grau A de Inteligência Artificial

Cronograma

- 31/08/16 - VOTAÇÃO
* Encontrar o bairro para desenvolver o trabalho;
	* Vila Conceição;

	
	
- 07/09/16 - VOTAÇÃO
	* Pesquisar melhor forma de coletar as ruas (nodos) identificar esquinas para assim formar o grafo;
		A principio estamos utilizando o http://www.openstreetmap.org/

Wiki dos arquivos exportados em XML:
http://wiki.openstreetmap.org/wiki/OSM_XML

Wiki das tags contidas em cada XML:
http://wiki.openstreetmap.org/wiki/Elements